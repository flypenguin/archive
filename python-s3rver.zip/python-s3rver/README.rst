S3rver
======

A stateless, S3-backed, Flask-based web server for serving static files out of S3.

Really the most basic implementation one could imagine, so be careful for production use.

For documentation, see the `GitHub repository`_.

A docker container for s3rver is `available on quay`_.

.. _`GitHub repository`: https://github.com/flypenguin/python-s3rver
.. _`available on quay:` https://quay.io/flypenguin/s3rver
