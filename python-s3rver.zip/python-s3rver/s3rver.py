#!/usr/bin/env python

import sys

from s3rver import serve


if __name__ == "__main__":
    serve(cmdline_args=sys.argv[1:])
