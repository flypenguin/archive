# S3RVER

A super stupid flask application that serves static content from S3.


## QUICKSTART

```bash
$ pip install s3rver
$ export AWS_ACCESS_KEY_ID=xxx
$ export AWS_SECRET_ACCESS_KEY=yyy
$ export AWS_DEFAULT_REGION=zzz
$ s3rver -h
$ s3rver -b my-bucket -p my/pre/fix
[...]
```

The example will serve files from `s3://my-bucket/my/pre/fix` as "/" 

Note that you **must configure AWS credentials, even for calling -h**! This is a current limitation which I intend to address.


## FEATURES

* auto lookup of `index.html` (if the file/path given cannot be found, `/index.html` is appended and the whole thing is tried again)
* a docker container of this is available on quay: `quay.io/flypenguin/s3rver`


## DEFAULT PATHS

* `/health` - for health checks. Has precedence over S3, so any path starting with this in S3 will be unreachable.
* `/version` - returns the version number. Also has precedence over S3.


## CAVEATS

* *NO* security checks
* You *have* to use the AWS_* environment variables to configure AWS access if you're not on an EC2 host
* Pretty crappy state (see requirement of AWS credentials, even for help)
