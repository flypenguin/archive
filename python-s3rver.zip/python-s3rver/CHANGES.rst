CHANGELOG
=========

0.3.0
-----

Date: 2017-02-08

- FEATURE: Add ``/health`` and ``/version`` paths
- FIX: ``EXPOSE`` container port in Dockerfile


0.2.0
-----

Date: 2017-02-08

- FEATURE: Add ``--debug`` flag
- FIX: Bind to ``0.0.0.0`` now (instead of ``127.0.0.1``)
- FIX: Dockerfile port exposure
- FIX: DEBUG no longer enabled by default


0.1.0
-----

Date: 2017-01-25

- INITIAL RELEASE
