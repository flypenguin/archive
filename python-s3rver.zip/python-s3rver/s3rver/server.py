import os
import sys
from argparse import ArgumentParser

from dotmap import DotMap
from flask import Flask, Response
from gevent import monkey

from .aws import *
from .version import __version__


args = None
app = Flask(__name__)

S3RVER_PREFIX_DEFAULT = "s3rver/"


# this is super-duper-wooper-shitty. it is needed because otherwise boto3/
# botocore will raise exceptions about every 2nd time they are used, and the
# API is completely unusable. I really don't like this, because it's black
# magic of the worst kind.
# http://www.gevent.org/gevent.monkey.html
# https://is.gd/D9ojK0 (example of someone doing it, without explanation)
monkey.patch_all()


def _stream_file(s3_object):
    stream = s3_object['Body']
    data = stream.read(65500)
    while data:
        yield data
        data = stream.read(65500)


@app.route('/health')
def health():
    return "OK", 200


@app.route('/version')
def version():
    return __version__, 200


@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def index(path):
    # first of all, prepend the prefix
    lookup_path = args.prefix + path

    # weirdly enough, you can actually get DIRS on S3. which is strange.
    # so, if we have a dir, just append index.html directly
    retry = True
    if lookup_path[-1] == "/":
        lookup_path = lookup_path + "index.html"
        retry = False

    # now, first attempt of getting the file
    serve_me = s3_get_file(args.bucket, lookup_path, catch=True)

    # IF we didn't already correct for a path, re-try with /index.html appended
    if serve_me is None and retry:
        # the previous "file" didnt exist. now try this as directory
        # and append index.html, maybe this works.
        serve_me = s3_get_file(args.bucket,
                               lookup_path + "/index.html",
                               catch=True)

    # return "booh" or the actual file. use the content-type from S3
    if serve_me is None:
        return "File not found: {}".format(path), 404
    return Response(_stream_file(serve_me),
                    content_type=serve_me['ContentType'])


def parse_args(cmdline_args=[], **kwargs):
    global args
    parser = ArgumentParser()
    parser.add_argument("-b", "--bucket",
                        default=os.environ.get("S3RVER_BUCKET", None),
                        help="Specify S3 bucket to use. Required."
                             "Taken from $S3RVER_BUCKET if not set.")
    parser.add_argument("-p", "--prefix",
                        default=os.environ.get("S3RVER_PREFIX",
                                               S3RVER_PREFIX_DEFAULT),
                        help="Specify bucket path prefix for lookups. "
                             "Default: $S3RVER_PREFIX or '{}'".format(
                            S3RVER_PREFIX_DEFAULT
                        ))
    parser.add_argument("--debug",
                        action="store_true",
                        default=os.environ.get("S3RVER_DEBUG", "0").lower()
                                in ("1", "true", "on", "yes", "enabled"),
                        help="Enable debug mode for Flask. Default is "
                             "$S3RVER_DEBUG or False")
    parser.add_argument("-V", "--version",
                        action='store_true',
                        default=False,
                        help="Print version number and exit.")

    args = DotMap(vars(parser.parse_args(cmdline_args)))
    args.update(kwargs)

    if args.version:
        print("{}".format(__version__))
        sys.exit()

    if args.bucket is None:
        print("ERROR: You must specify a bucket - either use -b/--bucket, "
              "or set $S3RVER_BUCKET")
        sys.exit(-1)

    # let's do some validation
    if args.prefix[1] == "/":
        args.prefix = args.prefix[1:]
    if args.prefix[-1] != "/":
        args.prefix += "/"


def serve(cmdline_args=[], **kwargs):
    parse_args(cmdline_args=cmdline_args, **kwargs)
    app.run(host="0.0.0.0", debug=args.debug)
