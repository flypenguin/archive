# shamelessly copied from health-rsas.

import numbers
import gzip

import boto3
from io import BytesIO
from botocore.exceptions import ClientError


s3 = boto3.resource('s3')
sqs = boto3.resource('sqs')


def s3_put_file(bucket_name, path, data,
                compress=None,
                **metadata):
    """
    Puts a package into the designated package file. You can use the 'metadata'
    parameter to set the content-type of the data. This is being given to the
    AWS library as-is, so to set the Content-Type data field you need to use
    'ContentType' for example. See AWS docs for details.

    :param bucket_name: The bucket to use
    :param path: The full file path in S3
    :param data: The package content
    :param compress: String value, should align with the HTTP header
    'Content-Encoding' type. If set it should contain the compression algorithm
    to be used to compress the data before putting it to S3. Currently only
    'gzip' is supported. If compression is enabled the ContentEncoding
    parameter of boto3.S3.Object.put() is set.
    :param content_type: String value, passed through to
    S3.put(ContentType=...). Defaults to 'application/octet-stream'.
    :param metadata: Arbitrary metadata, directly passed through to
    S3.Object.put(**metadata).
    :return: the result from s3.Object.put()
    """
    if metadata is None:
        metadata = {}
    if compress is not None:
        if compress == 'gzip':
            data = gzip.compress(data)
            metadata['ContentEncoding'] = compress
        else:
            raise ValueError('invalid value for s3 compress method: {}'
                             .format(compress))
    return s3.Object(bucket_name, path).put(
        Body=data,
        ContentLength=len(data),
        **metadata
    )


def s3_get_file(bucket_name, path, catch=False):
    """
    Retrieves a package from S3. A *very* simple wrapper around s3.Object.get().
    The main reason is to have a "consistent API" in this wrapper thing here,
    and to throw a KeyError if the key to the file could not be found.
    :param bucket_name: The bucket to use
    :param path: The path to the file in the bucket
    :param catch: If set to true no exception is raised when a key could not be
    found
    :return: The package content
    """
    # sis is really pitonic.
    tmp = None
    try:
        return s3.Object(bucket_name, path).get()
    except ClientError as ex:
        if str(ex).find('NoSuchKey') > -1:
            if not catch:
                raise KeyError(id)
        else:
            raise ex
    return tmp


def s3_get_file_stream_and_type(bucket_name, path, catch=False):
    """
    Convenience wrapper around s3_get_file. Decompresses the file contents
    if content-encoding is set to "gzip", and returns the file's contents
    and the file type (from content-encoding) accordingly.

    :param bucket_name: Put through to s3_get_file
    :param path: Put through to s3_get_file
    :param catch: Put through to s3_get_file
    :return: A tuple (file_stream, content_type). If the contents are
    decompressed a python StringIO object instance is returned - it will
    *always* be a IO-like object.
    """
    tmp = s3_get_file(bucket_name, path, catch)
    rv = tmp['Body']
    ctype = tmp.get('ContentType', 'binary/octet-stream')
    cenc = tmp.get('ContentEncoding', None)
    if cenc is not None:
        if cenc == 'gzip':
            # TODO - use a wrapper class to stream-uncompress zipped contents
            rv = BytesIO(gzip.decompress(tmp['Body'].read()))
        else:
            raise ValueError("Cannot read files from S3 "
                             "with ContentEncoding '{}'".format(cenc))
    return rv, ctype


def s3_get_available_files(bucket_name, below=""):
    """
    Returns all available packages in the currently configured dir structure.
    :param bucket_name: The bucket to use
    :param below: List only files below this 'path' in S3
    :return: A list of package names
    """
    if below[1] == "/":
        below = below[1:]
    tmp1 = filter(lambda x: x._key.startswith(below),
                  s3.Bucket(bucket_name).objects.all())
    tmp2 = [x._key.replace(below+"/", "") for x in tmp1]
    return tmp2


def s3_delete_file(bucket_name, path):
    """
    Delete an S3 resource.
    :param bucket_name: The bucket name
    :param path: The path to the file to delete
    :return: The return value of s3.Object.delete()
    """
    tmp = s3.Object(bucket_name, path)
    return tmp.delete()


def s3_delete_obj(bucket_name, path):
    """
    Delete an S3 resource.
    :param bucket_name: The bucket name
    :param path: The path to the file to delete
    :return: The return value of s3.Object.delete()
    """
    bucket = s3.Bucket(bucket_name)
    for obj in bucket.objects.filter(Prefix= path):
        s3.Object(bucket.name, obj.key).delete()


def sqs_create_queue(name, attrs=None):
    """
    Simply creates an SQS queue.
    :param name: The name of the queue to create.
    :param attrs: Custom attributes for the AWS call. See AWS docs.
    :return: The URL of the queue.
    """
    return sqs.create_queue(QueueName=name,
                            Attributes={} if attrs is None else attrs)


def _create_message_attributes(attribute_dict):
    """
    Message can have key-value metadata assigned in the form of attributes.
    These attributes can have different types - Binary, Number or String. This
    This is why the attributes dict is *not* a simple { 'name' : 'value' } dict,
    but a more complex dict like this:

        { 'name': { 'DataType': '...', 'SOMEValue': '...' } }

    This method creates this attribute dict based on a "simple" key-value dict,
    by evaluating the data type of the value. Supprted are numeric data types,
    string data types, and binary arrays (b'' types).

    For more information see the AWS docs: https://is.gd/KADUF2

    :param attribute_dict: A simple attribute dict
    :return: An AWS-SQS compatible attribute dict
    """
    if attribute_dict is None:
        return {}
    rv = {}
    for name, value in attribute_dict.items():
        attr = {}
        rv[name] = attr
        if isinstance(value, bytes):
            attr['BinaryValue'] = value
            attr['DataType'] = 'Binary'
        else:
            attr['StringValue'] = str(value)
            attr['DataType'] = 'String' \
                if not isinstance(value, numbers.Number) \
                else 'Number'
    return rv


def sqs_queue_create_message(queue, content, delay_seconds=0, attributes=None):
    """
    Creates a message in an SQS queue.
    :param queue: The boto3 queue object
    :param content: The content of the message as String
    :param delay_seconds: The desired delay_seconds
    :param attributes: A key-value dict for message attributes
    :return: The return value of queue.create_message
    """
    attrs = _create_message_attributes(attributes)
    return queue.send_message(MessageBody=content,
                              DelaySeconds=delay_seconds,
                              MessageAttributes=attrs)


def sqs_queue_items(queue, infinite=True):
    """
    A generator yielding items of an SQS queue.
    :param queue: The queue to subscribe to
    :param infinite: Whether to stop once no message could be read, or to
    continue indefinitely.
    :return: The received message object
    """
    continue_loop = True
    while continue_loop:
        message_list = queue.receive_messages(WaitTimeSeconds=20,
                                              MaxNumberOfMessages=1)
        if len(message_list) > 0:
            yield message_list[0]
        continue_loop = infinite
