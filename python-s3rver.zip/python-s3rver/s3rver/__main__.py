from s3rver import console_entrypoint

if __name__ == "__main__":
    console_entrypoint()

