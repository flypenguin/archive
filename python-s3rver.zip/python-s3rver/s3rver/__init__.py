import sys

from .server import serve


def console_entrypoint():
    serve(cmdline_args=sys.argv[1:])


if __name__ == "__main__":
    console_entrypoint()
