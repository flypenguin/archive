Cattleprod
==========

A quick-and-dirty Python wrapper for the Rancher API. Tries do be dynamic in what it does, so that every API action is mapped dynamically into the API without the need to update source code. For a quickstart introduction please see the github repository.

The wrapper is far from complete, so YMMV if you try to use it, but I hope it is stable.
