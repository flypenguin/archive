Please see GitHub URL for documentation: https://github.com/flypenguin/python-cattleprod

