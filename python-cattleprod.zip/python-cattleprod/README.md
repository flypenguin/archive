# cattleprod

**NOTE:** This is the `master` branch readme. Please see the version tag README for the documentation relevant for the PyPI uploaded software!

A quick hack interface to the [Rancher](http://www.rancher.com) API.


## Getting started

```python
#!/usr/bin/env python3

# should also work with python2.
# you can copy and paste this, just change the rancher_url below.

from cattleprod import poke
from pprint import pprint
from requests import HTTPError

rancher_url = "http://my_rancher_url/v1"

rod = poke(rancher_url)
services = rod.get_services()
srv = t.get_services()[0]           # just take the first one ...
print(srv.name + ", " + srv['uuid'])
try:
    srv.do_restart()                # ... and try to restart it :)
except HTTPError as e:
    # standard requests behavior using rsp.raise_for_status()
    print("Nope.")
    pprint(e.response.json())       # <- this way you get the underlying info
# now the real thing

# same as calling requests.post(RANCHER_URL,rollingRestartStrategy=False)
answer = srv.do_restart(rollingRestartStrategy=False)
# done. :)
```

Authentication can be done like this:

```python
from cattleprod import poke

# let's assume rancher_url, akey and skey is set
starting_point = poke(rancher_url, auth=(akey, skey))

# ... or ...
starting_point = poke(rancher_url, akey, skey)

# ... or ...
from requests import HTTPBasicAuth
starting_point = poke(rancher_url, auth=HTTPBasicAuth(akey, skey))
```

Generally speaking, any parameter (except `akey` and `skey`) will be saved and
used in any call to `requests.(get|post|...)`, which is used internally to
communicate with the Rancher API.


## A bit more detail

If you look in the Rancher API using the web UI, you will see some always repeating data structures. Before you continue reading, please open your Rancher installation under `http://RANCHER_URL:RANCHER_PORT/v1/environments`.


### The Mapping between Rancher data and Rod objects

If you look at your API URL from above and browse around, you will see a couple of repeating data structures. The mapping of those data structures to the Rod object is always the same.

Basically the Rod instance is a subclass of the really nice [DotMap](https://github.com/drgrib/dotmap/) python class, which creates a dict whose members are accessible by the dot notation (`dict_instance.b = c`). On top of that the Rod instance provides some convenience methods on itself, based on the underlying Rancher data structure.

1. Every link under the `links` member is converted to a `get_*()` function. So the `links.account` link can be invoked by calling `rod.get_account()`. (but you can of course still access `links.account` to get the actual URL behind this)
1. Every link under the `actions` member is converted to a `do_*()` function. So you can restart a service by calling `rod.do_restart(restart_info)`. The data you can pass in is optional, if it's a dict a JSON conversion is done automatically. (But you can of course still access `actions.*` to get ... you know)
1. Everything else is accessible either as dict-style or dot-style on the Rod object instance (`service.name` is the same as `service['name']`).

Feel free to contact me about bugs, comments, rants, and praise ;) .
