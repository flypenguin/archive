# Test files

The files with the same prefix belong together. E.g. `test0-intmaniac.yaml` and `test0-compose.yaml`. 

Run them with `intmaniac -c test0-intmaniac.yaml`.
