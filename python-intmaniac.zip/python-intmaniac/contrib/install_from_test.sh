pip install -i https://testpypi.python.org/pypi intmaniac $@

