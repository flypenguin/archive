#!/usr/bin/env python

from intmaniac import console_entrypoint

if __name__ == "__main__":
    console_entrypoint()
