
LOG_FORMAT_CONSOLE = "\n%(asctime)s %(levelname)-8s %(name)-12s\n%(message)s"
LOG_FORMAT_FILEOUT = "\n%(asctime)s %(levelname)-8s\n%(message)s"

