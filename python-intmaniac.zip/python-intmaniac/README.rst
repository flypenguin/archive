INTManiac
=========

A docker-compose based integration / user acceptance test / whatever test tool. For more information please `see the GitHub page`_.

.. _`see the GitHub page`: https://github.com/flypenguin/python-intmaniac
